"""Task 01: n-gram counting."""

EOS = "_EOS_"
UNK = "_UNK_"


def count_ngrams(lines, n):
    """Count next-token frequencies for an n-gram language model.

    Args:
        lines: iterable of strings. Each string is a whitespace-tokenized line.
        n: n-gram order. Must be positive.

    Returns:
        A mapping from prefix tuples of length ``n - 1`` to mappings/counters
        of next-token counts. Each line should be treated as ending with EOS.
        Short prefixes should be left-padded with UNK.
    """
    raise NotImplementedError
