"""Task 02: n-gram language model."""


class NGramLanguageModel:
    """A simple maximum-likelihood n-gram language model."""

    def __init__(self, lines, n):
        """Build an n-gram language model from training lines."""
        raise NotImplementedError

    def get_possible_next_tokens(self, prefix):
        """Return a probability distribution over possible next tokens."""
        raise NotImplementedError

    def get_next_token_prob(self, prefix, next_token):
        """Return P(next_token | prefix)."""
        raise NotImplementedError
